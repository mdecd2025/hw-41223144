import sys
import os
import json
import socket
import threading
import time
from controller import Supervisor, Keyboard as WebotsKeyboard
from websocket_server import WebsocketServer
import keyboard

# 設定 Webots Python 模組路徑
sys.path.append(os.path.join(os.environ.get('WEBOTS_HOME', ''), 'lib', 'controller', 'python'))

# 常數設定
TIME_STEP = 32
MAX_VELOCITY = 10.0

# 初始化 Webots 控制器
robot = Supervisor()
webots_keyboard = WebotsKeyboard()
webots_keyboard.enable(TIME_STEP)
wheel1 = robot.getDevice("motor")
wheel1.setPosition(float('inf'))
wheel1.setVelocity(0)

def set_wheel_velocity(v1):
    wheel1.setVelocity(v1)

def reset_simulation():
    print("[反饋] Simulation: 重設 Webots 世界 (simulationReset) 並馬達停止")
    set_wheel_velocity(0)
    robot.simulationReset()

def pause_simulation():
    print("[反饋] Simulation: 暫停 Webots 世界 (simulationSetMode PAUSE) 並馬達停止")
    set_wheel_velocity(0)
    robot.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)

def resume_simulation():
    print("[反饋] Simulation: 恢復 Webots 世界 (simulationSetMode REAL_TIME)")
    robot.simulationSetMode(Supervisor.SIMULATION_MODE_REAL_TIME)

class IPv6WebsocketServer(WebsocketServer):
    def __init__(self, host, port):
        self.address_family = socket.AF_INET6
        super().__init__(host=host, port=port)

def on_message(client, server, message):
    print(f"收到新訊息: {message}")
    try:
        data = json.loads(message)
        direction = data.get("direction")
        if direction:
            direction = direction.lower()
            if direction == "q":
                print("[反饋] WebSocket: 啟動馬達")
                set_wheel_velocity(MAX_VELOCITY)
            elif direction == "r":
                print("[反饋] WebSocket: 重設模擬")
                reset_simulation()
            elif direction == "esc":
                print("[反饋] WebSocket: 暫停模擬")
                pause_simulation()
            elif direction in ("resume", "run"):
                print("[反饋] WebSocket: 恢復模擬")
                resume_simulation()
            else:
                print("[反饋] WebSocket: 未知指令")
        else:
            print("[反饋] WebSocket: 無效的訊息格式")
    except json.JSONDecodeError:
        print("[反饋] WebSocket: 訊息解析錯誤")
    except Exception as e:
        print(f"[反饋] WebSocket: 錯誤 - {e}")

def start_websocket_server():
    server_ip = "2001:288:6004:17:fff1:cd25:0:a047"
    server_port = 8081
    try:
        server = IPv6WebsocketServer(host=server_ip, port=server_port)
        server.set_fn_message_received(on_message)
        print(f"WebSocket server started on [{server_ip}]:{server_port}, waiting for commands...")
        server.run_forever()
    except Exception as e:
        print(f"Failed to start WebSocket server: {e}")

def handle_keyboard_input():
    key = webots_keyboard.getKey()
    if key == ord('Q'):
        print("[反饋] Webots鍵盤: 啟動馬達")
        set_wheel_velocity(MAX_VELOCITY)
    elif key == ord('R'):
        print("[反饋] Webots鍵盤: 重設模擬")
        reset_simulation()
    elif key == ord('E'):
        print("[反饋] Webots鍵盤: 恢復模擬")
        resume_simulation()
    elif key == 27:  # ESC
        print("[反饋] Webots鍵盤: 暫停模擬")
        pause_simulation()

def start_arrow_key_control():
    print("terminal: 按 q 啟動馬達, r 重設, esc 暫停, e 恢復")
    while True:
        try:
            if keyboard.is_pressed("q"):
                print("[反饋] 本地鍵盤: 啟動馬達")
                set_wheel_velocity(MAX_VELOCITY)
                time.sleep(0.2)
            elif keyboard.is_pressed("r"):
                print("[反饋] 本地鍵盤: 重設模擬")
                reset_simulation()
                time.sleep(0.5)
            elif keyboard.is_pressed("esc"):
                print("[反饋] 本地鍵盤: 暫停模擬")
                pause_simulation()
                time.sleep(0.5)
            elif keyboard.is_pressed("e"):
                print("[反饋] 本地鍵盤: 恢復模擬")
                resume_simulation()
                time.sleep(0.5)
            time.sleep(0.05)
        except Exception as e:
            print(f"Error in arrow key control: {e}")
            break

def start_webots_simulation():
    try:
        while robot.step(TIME_STEP) != -1:
            handle_keyboard_input()
            time.sleep(0.05)
    except Exception as e:
        print(f"Simulation error: {e}")

if __name__ == "__main__":
    websocket_thread = threading.Thread(target=start_websocket_server, daemon=True)
    simulation_thread = threading.Thread(target=start_webots_simulation, daemon=True)
    arrow_key_thread = threading.Thread(target=start_arrow_key_control, daemon=True)

    websocket_thread.start()
    simulation_thread.start()
    arrow_key_thread.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down gracefully...")
